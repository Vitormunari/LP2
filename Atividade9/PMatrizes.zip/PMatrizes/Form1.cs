﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExerc1_Click(object sender, EventArgs e)
        {
            int[] Vetor = new int[20];
            string auxiliar = "";

            for(var i=0;i<20;i++) 
            {
                auxiliar = Interaction.InputBox("Digite o número" + (i + 1).ToString(),
                    "Entrada de Dados");
                if(!int.TryParse(auxiliar, out Vetor[i])) 
                {
                    MessageBox.Show("número inválido");
                    i--;
                }
            }

            //ordem inversa
            auxiliar = "";
            for(var i=19;i>=0;i--)
            {
                auxiliar += "\n" + Vetor[i].ToString();
            }
                MessageBox.Show(auxiliar);
            
            //ordem inversa usando reverse
            Array.Reverse(Vetor);
            auxiliar = "";

            foreach(var j in Vetor) 
            { 
                auxiliar = "\n" + j.ToString();
            }
                MessageBox.Show(auxiliar);
        }

        private void btnExerc2_Click(object sender, EventArgs e)
        {
            double[] Quantidade = new double[10];
            double[] Preco = new double[10];

            string auxiliar = "";
            double faturamento = 0;
            for(var i=0;i<10;i++) 
            {
                auxiliar = Interaction.InputBox("Digite Quantidade" + (i + 1).ToString(),
                    "Entrada das Quantidades");
                if(!double.TryParse(auxiliar,out Quantidade[i])) 
                {
                    MessageBox.Show("Quantidade Inválida");
                    i--;
                }
                else
                {
                    while (Preco[i] <= 0)
                    {
                        auxiliar = "";
                        auxiliar = Interaction.InputBox("Digite o Preço" + (i + 1).ToString(),
                            "Entrada dos Preços");
                        if(double.TryParse(auxiliar, out Preco[i]))
                        {
                            faturamento += Quantidade[i] * Preco[i]; 
                        }
                        else
                        {
                            MessageBox.Show("Preço Inválido");
                        }
                    }
                }
            }
            MessageBox.Show("Faturamento em R$: " + faturamento.ToString());
        }
    }
}
