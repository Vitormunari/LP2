﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExerc1 = new System.Windows.Forms.Button();
            this.btnExerc2 = new System.Windows.Forms.Button();
            this.btnExerc3 = new System.Windows.Forms.Button();
            this.btnExerc4 = new System.Windows.Forms.Button();
            this.btnExerc5 = new System.Windows.Forms.Button();
            this.btnExerc6 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExerc1
            // 
            this.btnExerc1.Location = new System.Drawing.Point(58, 81);
            this.btnExerc1.Name = "btnExerc1";
            this.btnExerc1.Size = new System.Drawing.Size(114, 64);
            this.btnExerc1.TabIndex = 0;
            this.btnExerc1.Text = "Exercício 1";
            this.btnExerc1.UseVisualStyleBackColor = true;
            this.btnExerc1.Click += new System.EventHandler(this.btnExerc1_Click);
            // 
            // btnExerc2
            // 
            this.btnExerc2.Location = new System.Drawing.Point(270, 81);
            this.btnExerc2.Name = "btnExerc2";
            this.btnExerc2.Size = new System.Drawing.Size(108, 64);
            this.btnExerc2.TabIndex = 1;
            this.btnExerc2.Text = "Exercício 2";
            this.btnExerc2.UseVisualStyleBackColor = true;
            this.btnExerc2.Click += new System.EventHandler(this.btnExerc2_Click);
            // 
            // btnExerc3
            // 
            this.btnExerc3.Location = new System.Drawing.Point(457, 81);
            this.btnExerc3.Name = "btnExerc3";
            this.btnExerc3.Size = new System.Drawing.Size(101, 64);
            this.btnExerc3.TabIndex = 2;
            this.btnExerc3.Text = "Exercício 3";
            this.btnExerc3.UseVisualStyleBackColor = true;
            // 
            // btnExerc4
            // 
            this.btnExerc4.Location = new System.Drawing.Point(58, 193);
            this.btnExerc4.Name = "btnExerc4";
            this.btnExerc4.Size = new System.Drawing.Size(114, 57);
            this.btnExerc4.TabIndex = 3;
            this.btnExerc4.Text = "Exercício 4";
            this.btnExerc4.UseVisualStyleBackColor = true;
            // 
            // btnExerc5
            // 
            this.btnExerc5.Location = new System.Drawing.Point(270, 193);
            this.btnExerc5.Name = "btnExerc5";
            this.btnExerc5.Size = new System.Drawing.Size(108, 57);
            this.btnExerc5.TabIndex = 4;
            this.btnExerc5.Text = "Exercício 5";
            this.btnExerc5.UseVisualStyleBackColor = true;
            // 
            // btnExerc6
            // 
            this.btnExerc6.Location = new System.Drawing.Point(457, 193);
            this.btnExerc6.Name = "btnExerc6";
            this.btnExerc6.Size = new System.Drawing.Size(101, 57);
            this.btnExerc6.TabIndex = 5;
            this.btnExerc6.Text = "Exercício 6";
            this.btnExerc6.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExerc6);
            this.Controls.Add(this.btnExerc5);
            this.Controls.Add(this.btnExerc4);
            this.Controls.Add(this.btnExerc3);
            this.Controls.Add(this.btnExerc2);
            this.Controls.Add(this.btnExerc1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExerc1;
        private System.Windows.Forms.Button btnExerc2;
        private System.Windows.Forms.Button btnExerc3;
        private System.Windows.Forms.Button btnExerc4;
        private System.Windows.Forms.Button btnExerc5;
        private System.Windows.Forms.Button btnExerc6;
    }
}

